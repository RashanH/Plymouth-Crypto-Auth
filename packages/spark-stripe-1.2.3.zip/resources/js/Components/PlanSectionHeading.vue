<template>
    <div class="font-bold text-sm text-gray-600 uppercase">
        <slot />
    </div>
</template>
